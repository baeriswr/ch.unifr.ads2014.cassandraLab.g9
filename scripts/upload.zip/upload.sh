#!/bin/bash

file=$(cat "group9.txt")
fileDynamic=$file

echo "USE group9;"
echo "BEGIN BATCH"

#Tables creation
echo "
CREATE TABLE MOVIELOOKUP (title varchar PRIMARY KEY,description varchar);
CREATE TABLE TOPMOVIES (title varchar PRIMARY KEY,rating float,varchar genre);
CREATE TABLE TOPACTORS (actor varchar PRIMARY KEY,popularity int);
"

#Data insertion
while IFS='<' read year title rating genres actors
 do  
  #MOVIELOOKUP 
  echo "INSERT INTO MOVIELOOKUP (title, description) VALUES ('$title', '$title released at $year which is a $genres film with $actors has obtained the rate $rating');"

  #TOPMOVIES
  if [ "$genres" != "" ] #sometimes there is no genre...
   then
    genreList=$(echo $genres | sed 's#|# #g')
    for g in $genreList
     do	
      echo "INSERT INTO TOPMOVIES (title, genre, rating) VALUES ('$title', '$g', '$rating');"		
     done
   else
    echo "INSERT INTO TOPMOVIES (title, genre, rating) VALUES ('$title', ', '$rating');"	
  fi
  
  #TOPACTORS
  actorList=$(echo $actors | sed 's#,# #g')
  for a in $actorList
   do
    popularity=$(echo "$fileDynamic" | grep "$a" | wc -l | sed 's# ##g') #FIXME ;-)
    fileDynamic=$(echo "$fileDynamic" | sed "s#$a##g") #update!
    echo "INSERT INTO TOPACTORS (actor, popularity) VALUES ('$a', '$popularity');"
   done
   
 done <<< "$file"

 
echo "APPLY BATCH;"



 
exit 0